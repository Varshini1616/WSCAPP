package com.wsclivmo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
@Service
public class BeneficiaryService {	
	@Autowired
	BeneficiaryRepository beneficiaryrepository;
    private List<Beneficiary> beneficiaries = new ArrayList<>();
    // Constructor to add default beneficiaries when the service starts
//    public BeneficiaryService() {
//        // Adding default beneficiaries
//        Beneficiary beneficiary1 = new Beneficiary(UUID.randomUUID().toString(), "John Doe", "Brother", "1234567890", "john.doe@example.com", "123 Main Street");
//        Beneficiary beneficiary2 = new Beneficiary(UUID.randomUUID().toString(), "Jane Doe", "Sister", "0987654321", "jane.doe@example.com", "456 Park Avenue");
//
//        beneficiaries.add(beneficiary1);
//        beneficiaries.add(beneficiary2);
//    }
    // Create a new beneficiary
    public Beneficiary createBeneficiary(Beneficiary beneficiary) {
        // Simulate a unique ID by generating a random UUID
        beneficiary.setId(UUID.randomUUID().toString());
        beneficiaryrepository.save(beneficiary);
        beneficiaries.add(beneficiary);
        return beneficiary;
    }

    // Retrieve all beneficiaries
    public List<Beneficiary> getAllBeneficiaries() {
        return beneficiaries;
    }

    // Retrieve a beneficiary by ID
    public Beneficiary getBeneficiaryById(String id) {
        return beneficiaries.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
//    // Update personal details by ID
    public Beneficiary updateBeneficiary(String id, Beneficiary updatedDetails) {
    	Beneficiary existingDetails = getBeneficiaryById(id);
        if (existingDetails != null) {
            existingDetails.setFirstName(updatedDetails.getFirstName());
            existingDetails.setLastName(updatedDetails.getLastName());
            existingDetails.setEmail(updatedDetails.getEmail());
            existingDetails.setMobileNumber(updatedDetails.getMobileNumber());
            existingDetails.setGender(updatedDetails.getGender());
            existingDetails.setDateOfBirth(updatedDetails.getDateOfBirth());
            existingDetails.setAddressLine1(updatedDetails.getAddressLine1());
            existingDetails.setAddressLine2(updatedDetails.getAddressLine2());
            existingDetails.setInsuranceName(updatedDetails.getInsuranceName());
            existingDetails.setMedicalHistory(updatedDetails.getMedicalHistory());
            existingDetails.setCountry(updatedDetails.getCountry());
            existingDetails.setState(updatedDetails.getState());
            existingDetails.setCity(updatedDetails.getCity());
            existingDetails.setZipCode(updatedDetails.getZipCode());

        }
        return existingDetails;
    }

    // Delete a beneficiary by ID
    public void deleteBeneficiary(String id) {
        beneficiaries.removeIf(b -> b.getId().equals(id));
    }
}
