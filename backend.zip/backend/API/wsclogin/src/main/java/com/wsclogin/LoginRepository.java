package com.wsclogin;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginRepository extends MongoRepository<Login, String> {
    // Custom query to find a user by their username
    Optional<Login> findByUsername(String username);
}
