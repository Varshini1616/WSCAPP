package com.wscapiapppersonal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowscapppersonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
