package com.wsclivmo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;

@Document(collection = "Beneficiary")

public class Beneficiary {

@Id
    private String id;
    private String beneficiaryname;
    private String beneficiarymobile;
    private String medicalhistory;
    // Constructors
    public Beneficiary() {}

    public Beneficiary(String id, String beneficiaryname, String beneficiarymobile, String medicalhistory) {
        this.id = id;
        this.beneficiaryname = beneficiaryname;
        this.beneficiarymobile = beneficiarymobile;
        this.medicalhistory = medicalhistory;
      
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBeneficiaryName() {
        return beneficiaryname;
    }

    public void setBeneficiaryName(String beneficiaryname) {
        this.beneficiaryname = beneficiaryname;
    }

    public String getBeneficiaryMobile() {
        return beneficiarymobile;
    }

    public void setBeneficiaryMobile(String beneficiarymobile) {
        this.beneficiarymobile = beneficiarymobile;
    }

    public String getMedicalHistory() {
        return medicalhistory;
    }

    public void setMedicalHistory(String medicalhistory) {
        this.medicalhistory = medicalhistory;
    }

    
	
		
		
	}

