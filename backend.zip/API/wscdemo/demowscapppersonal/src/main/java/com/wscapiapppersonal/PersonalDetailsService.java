package com.wscapiapppersonal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class PersonalDetailsService {

	
	@Autowired
	PersonalDetailsRepo personalDetailsRepo;
    
	private List<PersonalDetails> personalDetailsList = new ArrayList<>();
	 private AtomicInteger counter = new AtomicInteger(1); 
	 // Counter for ID generation
    // Constructor to add default personal details when the service starts
//    public PersonalDetailsService() {
//        PersonalDetails person1 = new PersonalDetails(UUID.randomUUID().toString(), "John", "Doe", "john.doe@example.com", "1234567890", "123 Main Street", "yyyy", "rrty", "gghg", "tgff", "rtruyutu", "rtrdfdt", "6666");
//        
//        personalDetailsList.add(person1);
//       
//    }

  //   Create new personal details
    public PersonalDetails createPersonalDetails(PersonalDetails personalDetails) {
        String generatedId = generateCustomId();
        personalDetails.setId(generatedId);
        personalDetailsRepo.save(personalDetails);
        return personalDetails;
    }

    // Generate custom ID in the format "wsc00099"
    private String generateCustomId() {
        // Format the ID with a prefix "wsc" and pad the counter value with leading zeros to ensure 5 digits
        return String.format("wsc%05d", counter.getAndIncrement());
    }

    // Retrieve all personal details
    public List<PersonalDetails> getAllPersonalDetails() {
        return personalDetailsList;
    }

    // Retrieve personal details by ID
    public PersonalDetails getPersonalDetailsById(String id) {
        return personalDetailsList.stream()
                .filter(details -> details.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    // Update personal details by ID
    public PersonalDetails updatePersonalDetails(String id, PersonalDetails updatedDetails) {
        PersonalDetails existingDetails = getPersonalDetailsById(id);
        if (existingDetails != null) {
            existingDetails.setFirstName(updatedDetails.getFirstName());
            existingDetails.setLastName(updatedDetails.getLastName());
            existingDetails.setEmail(updatedDetails.getEmail());
            existingDetails.setMobileNumber(updatedDetails.getMobileNumber());
            existingDetails.setGender(updatedDetails.getGender());
            existingDetails.setDOB(updatedDetails.getDOB());
            existingDetails.setAddressLine1(updatedDetails.getAddressLine1());
            existingDetails.setAddressLine2(updatedDetails.getAddressLine2());
            existingDetails.setCountry(updatedDetails.getCountry());
            existingDetails.setState(updatedDetails.getState());
            existingDetails.setCity(updatedDetails.getCity());
            existingDetails.setZipCode(updatedDetails.getZipCode());
        }
        return existingDetails;
    }

    // Delete personal details by ID
    public void deletePersonalDetails(String id) {
        personalDetailsList.removeIf(details -> details.getId().equals(id));
    }
}
