package com.wsclivmo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WscApplicationTests {

	@Test
	void contextLoads() {
	}

}
