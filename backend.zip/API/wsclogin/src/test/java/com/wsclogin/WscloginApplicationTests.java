package com.wsclogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WscloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
