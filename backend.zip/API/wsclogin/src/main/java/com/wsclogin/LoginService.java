package com.wsclogin;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class LoginService {
    @Autowired
     LoginRepository loginRepository;
   // private List<Login>login = new ArrayList<>();
    
    public Login createLogin (Login login) {
    	loginRepository.save(login);
    	return login;
    };	  
    // Method to check login credentials
    public boolean loginUser(String username, String password) {
        Optional<Login> login = loginRepository.findByUsername(username);
        if (login.isPresent()) {
            // Compare the provided password with the stored password
            return password.equals(login.get().getPassword()); // Plain text password comparison
        }
        else {
        return false;
        }
    }	
}