package com.wsclogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/login")
@CrossOrigin(origins = "http://localhost:8081/")
public class LoginController {
    @Autowired
    private LoginService loginService;
    // Endpoint to login a user (POST method)
    @PostMapping
    public ResponseEntity<?> loginUser(@RequestBody LoginRequestDTO loginRequest) {
        boolean isAuthenticated = loginService.loginUser(loginRequest.getUsername(), loginRequest.getPassword());
        if (isAuthenticated) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(401).body("Invalid username or password");
        }
    }

    // Optional: Endpoint to check the status of the authentication service (GET method)
    @GetMapping
    public ResponseEntity<String> getStatus() {
        return ResponseEntity.ok("Auth service is running");
    }
}
