package com.mvplivmo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivmoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivmoApplication.class, args);
	}

}
