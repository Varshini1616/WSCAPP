package com.mvplivmo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/signup") // This means all requests will already be under "/api/signup"
@CrossOrigin(origins = "http://localhost:8081") // Ensure this matches your frontend port
public class SignUpController {

    @Autowired
    private SignUpService signUpService;

    // Endpoint to handle user registration
    @PostMapping // No need to specify "api/signup" here again
    public ResponseEntity<SignupresponseDTO> registerUser(@Valid @RequestBody SignuprequestDTO signuprequestDTO) {
        try {
            SignupresponseDTO savedUser = signUpService.registerUser(signuprequestDTO);
            return ResponseEntity.ok(savedUser);
        } catch (IllegalStateException e) {
            return ResponseEntity.status(400).body(null); // You can add a custom error message if needed
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null); // You can also return a custom error message for debugging
        }
    }
}
