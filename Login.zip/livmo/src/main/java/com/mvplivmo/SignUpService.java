package com.mvplivmo;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SignUpService {

    @Autowired
    private SignUpRepo signUpRepo;

    // Method to register a new user
    public SignupresponseDTO registerUser(SignuprequestDTO signUpRequestDTO) {
        // Check if a user with the same email already exists
        Optional<SignUp> existingUser = signUpRepo.findById(signUpRequestDTO.getEmail());
        if (existingUser.isPresent()) {
            throw new IllegalStateException("User with this email already exists.");
        }

        // Check if a user with the same mobile number already exists
        Optional<SignUp> existingMobileUser = signUpRepo.findByMobileNumber(signUpRequestDTO.getMobileNumber());
        if (existingMobileUser.isPresent()) {
            throw new IllegalStateException("User with this mobile number already exists.");
        }

        // Map DTO to the entity
        SignUp newUser = new SignUp(
            signUpRequestDTO.getFirstName(),
            signUpRequestDTO.getLastName(),
            signUpRequestDTO.getEmail(),
            signUpRequestDTO.getMobileNumber(),
            signUpRequestDTO.getPassword(),
            signUpRequestDTO.getConfirmPassword()
        );

        // Save the new user to the database
        signUpRepo.save(newUser);

        // Return response DTO
        return new SignupresponseDTO(newUser.getFirstName(), newUser.getLastName(), newUser.getEmail(), newUser.getMobileNumber());
    }

    // Other service methods remain unchanged...
}
